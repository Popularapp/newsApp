
const title = "Popular App";
const imageReplacer = "extra.png";
const website = "popularapp.in";
const appId = "com.technotwist.popularapp";
const class1 = "col-8 desc";
const class2 = "col-4 front-image";
const favicon = "tr_logo.png";
const logo_path = 'popular';

//also update the firebase variable in user-login.ejs

module.exports = {title,imageReplacer,website,appId,class1,class2,favicon,logo_path};